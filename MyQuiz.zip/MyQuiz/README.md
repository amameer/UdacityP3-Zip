# UdacityProject3” >> README.md
git init
echo # UdacityProject3”
# UdacityProject3” >> README.md

echo # UdacityProject3”
